﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.Models;

namespace WebApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        // Pages.
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult OneFilm()
        {
            Film model = _context.Films.FirstOrDefault();
            return View(model);
        }

        public IActionResult AllFilms()
        {
            List<Film> model = _context.Films.ToList();
            return View(model);
        }

        public IActionResult URatedFilms()
        {
            var URatedFilm = from f in _context.Films where f.FilmCertificate == "U" select f;
            List<Film> model = URatedFilm.ToList();
            return View(model);
        }

        public IActionResult PGRatedFilms()
        {
            var PGRatedFilm = from f in _context.Films where f.FilmCertificate == "PG" select f;
            List<Film> model = PGRatedFilm.ToList();
            return View(model);
        }


        public IActionResult TwelveRatedFilms()
        {
            var TwelveRatedFilm = from f in _context.Films where f.FilmCertificate == "12" select f;
            List<Film> model = TwelveRatedFilm.ToList();
            return View(model);
        }

        public IActionResult FifteenRatedFilms()
        {
            var FifteenRatedFilm = from f in _context.Films where f.FilmCertificate == "15" select f;
            List<Film> model = FifteenRatedFilm.ToList();
            return View(model);
        }

        public IActionResult EighteenRatedFilms()
        {
            var EighteenRatedFilm = from f in _context.Films where f.FilmCertificate == "18" select f;
            List<Film> model = EighteenRatedFilm.ToList();
            return View(model);
        }

        public IActionResult FilmDetails(int id)
        {
            Film model = _context.Films.Find(id);
            return View(model);
        }

        public IActionResult Search(string SearchString)
        {
            if (!string.IsNullOrEmpty(SearchString))
            {
                var films = from m in _context.Films where m.FilmTitle.Contains(SearchString) select m;
                List<Film> model = films.ToList();
                ViewData["SearchString"] = SearchString;
                return View(model);
            }
            else
            {
                return View();
            }
        }

        public IActionResult Login()
        {
            return View();
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
